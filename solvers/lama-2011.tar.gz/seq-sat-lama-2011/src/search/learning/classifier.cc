#include "classifier.h"

Classifier::Classifier() {
}

Classifier::~Classifier() {
}
