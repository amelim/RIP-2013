#ifndef UTILITIES_H
#define UTILITIES_H

extern void register_event_handlers();

extern int get_peak_memory_in_kb();
extern void print_peak_memory();

#endif
